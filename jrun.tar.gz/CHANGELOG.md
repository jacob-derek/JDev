## JRun
- ↑/↓ (e Ctrl+N/P, PgUp/PgDn) agora movem a lista com o foco na caixa de busca (antes não moviam).
- Abre na hora: lista do cache enquanto os .desktop são relidos em segundo plano (jrcore.py).
- Busca com relevância (começo do nome > palavra > trecho > sigla > comando > comentário); no empate, o que você mais abre vem primeiro (~/.local/state/jdev/jrun-uso.json). Várias palavras: todas precisam casar.
- Apps de terminal abrem no JTerm; Exec= com %f/--arg=%c limpo direito; TryExec e Path= respeitados.
- `!cmd` ou `>cmd` roda no shell; pipes/$VAR/redirecionamento caem no `sh -c` sozinhos. `=2*(3+4)` calcula na hora.
- Trava de instância confere que o pid é mesmo do JRun (pid reaproveitado não bloqueia mais) e só apaga a própria; fonte do jtheme.
